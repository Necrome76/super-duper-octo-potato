package com.example.cardx

data class User(val t:Int = 0, val fN:String="", val lN:String=""){

    var theme: Int = t
    var firstName: String = fN
    var lastName: String = lN
}